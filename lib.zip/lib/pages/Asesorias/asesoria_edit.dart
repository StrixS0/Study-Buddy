import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AsesoriasEdit extends StatefulWidget {
  final Map<String, dynamic> asessoria;

  const AsesoriasEdit({Key? key, required this.asessoria}) : super(key: key);

  @override
  _AsesoriasEditState createState() => _AsesoriasEditState();
}

class _AsesoriasEditState extends State<AsesoriasEdit> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.asessoria['title']);
    _descriptionController = TextEditingController(text: widget.asessoria['description'] ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _saveChanges() {
    if (_formKey.currentState!.validate()) {
      FirebaseFirestore.instance.collection('asesorias').doc(widget.asessoria['id']).update({
        'nombreMateria': _titleController.text,
        'descripcion': _descriptionController.text,
      }).then((_) {
        Navigator.pop(context);
      }).catchError((error) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error al guardar cambios: $error')));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Asesoría'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(labelText: 'Título'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingrese un título';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Descripción'),
                maxLines: 5,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _saveChanges,
                child: Text('Guardar Cambios'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
