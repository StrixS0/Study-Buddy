import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AsesoriasDetail extends StatelessWidget {
  final Map<String, dynamic> asessoria;

  const AsesoriasDetail({Key? key, required this.asessoria}) : super(key: key);

  void _markAsImparted(BuildContext context) {
    FirebaseFirestore.instance
        .collection('asesorias')
        .doc(asessoria['id'])
        .update({'status': 'impartida'})
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Asesoría marcada como impartida')));
      Navigator.pop(context);
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al marcar como impartida: $error')));
    });
  }

  void _cancelAsesoria(BuildContext context) {
    FirebaseFirestore.instance
        .collection('asesorias')
        .doc(asessoria['id'])
        .update({'status': 'cancelada'})
        .then((_) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Asesoría cancelada')));
      Navigator.pop(context);
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cancelar la asesoría: $error')));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Información de tu Asesoría'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.network(
                asessoria['image'] ?? 'https://via.placeholder.com/400x258',
                height: 200,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              asessoria['title'],
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
            Text(
              asessoria['author'] ?? 'Autor no disponible',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(Icons.calendar_today),
                const SizedBox(width: 8),
                Text(asessoria['date']),
                const SizedBox(width: 16),
                Icon(Icons.access_time),
                const SizedBox(width: 8),
                Text(asessoria['time']),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'Asistentes',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            for (var asistente in asessoria['assistants']) Text(asistente),
            const SizedBox(height: 16),
            Text(
              'Etiquetas',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            Wrap(
              spacing: 8.0,
              children: asessoria['tags']
                  .map<Widget>((tag) => Chip(label: Text(tag)))
                  .toList(),
            ),
            const SizedBox(height: 16),
            Text(
              'Descripción',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            Text(
              asessoria['descripcion'] ?? 'No hay descripción disponible',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                    ),
                    builder: (context) => Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ListTile(
                            leading: Icon(Icons.edit),
                            title: Text('Editar Asesoría'),
                            onTap: () {
                              Navigator.pop(context);
                              // Lógica para editar la asesoría
                            },
                          ),
                          ListTile(
                            leading: Icon(Icons.check),
                            title: Text('Marcar como Impartida'),
                            onTap: () {
                              Navigator.pop(context);
                              _markAsImparted(context);
                            },
                          ),
                          ListTile(
                            leading: Icon(Icons.cancel),
                            title: Text('Cancelar Asesoría'),
                            onTap: () {
                              Navigator.pop(context);
                              _cancelAsesoria(context);
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
                child: Text('Opciones'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}