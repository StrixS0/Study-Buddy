import 'package:flutter/material.dart';
import 'Asesorias/to_teach.dart';
import 'Asesorias/taught.dart';
import 'Asesorias/to_take.dart';

class TeachingScreen extends StatefulWidget {
  @override
  _TeachingScreenState createState() => _TeachingScreenState();
}

class _TeachingScreenState extends State<TeachingScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Clases'),
        bottom: TabBar(
          controller: _tabController,
          indicator: UnderlineTabIndicator(
            borderSide: BorderSide(width: 4.0, color: Color.fromARGB(255, 107, 138, 210)),
            insets: EdgeInsets.symmetric(horizontal: 16.0),
          ),
          indicatorSize: TabBarIndicatorSize.label,
          tabs: const [
            Tab(text: 'A tomar'),
            Tab(text: 'A impartir'),
            Tab(text: 'Impartidas'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          ToTakeScreen(),
          ToTeachScreen(),
          TaughtScreen(),
        ],
      ),
    );
  }
}
