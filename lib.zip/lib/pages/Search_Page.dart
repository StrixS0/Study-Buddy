import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<String> popularTags = ['ITS', 'IAS', 'Java', 'HTML', 'CSS', 'React Js', 'DevOps', 'Machine Learning'];
  List<String> selectedTags = [];
  String searchTerm = '';
  List<Map<String, dynamic>> searchResults = [];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {
        searchTerm = _searchController.text.trim().toLowerCase();
      });
      _searchAdvisories();
    });
  }

  Future<void> _searchAdvisories() async {
    try {
      QuerySnapshot querySnapshot;

      if (searchTerm.isEmpty && selectedTags.isEmpty) {
        setState(() {
          searchResults = [];
        });
        return;
      }

      if (selectedTags.isNotEmpty) {
        querySnapshot = await FirebaseFirestore.instance
            .collection('asesorias')
            .where('tags', arrayContainsAny: selectedTags)
            .get();
      } else {
        querySnapshot = await FirebaseFirestore.instance
            .collection('asesorias')
            .where('nombreMateria', isGreaterThanOrEqualTo: searchTerm)
            .where('nombreMateria', isLessThanOrEqualTo: searchTerm + '\uf8ff')
            .get();
      }

      setState(() {
        searchResults = querySnapshot.docs.map((doc) {
          var data = doc.data() as Map<String, dynamic>;
          data['fecha'] = (data['fecha'] as Timestamp).toDate(); // Convertir Timestamp a DateTime
          return data;
        }).toList();
      });
    } catch (e) {
      print('Error searching advisories: $e');
      setState(() {
        searchResults = [];
      });
    }
  }

  void _toggleTag(String tag) {
    setState(() {
      if (selectedTags.contains(tag)) {
        selectedTags.remove(tag);
      } else {
        selectedTags.add(tag);
      }
    });
    _searchAdvisories();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buscar Asesorías'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200], // Color de fondo del campo de búsqueda
              ),
            ),
            const SizedBox(height: 16.0),
            const Text('Temas Populares', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8.0),
            Wrap(
              spacing: 8.0,
              children: popularTags.map((tag) {
                return ChoiceChip(
                  label: Text(tag),
                  selected: selectedTags.contains(tag),
                  onSelected: (_) {
                    _toggleTag(tag);
                  },
                  selectedColor: Colors.blue[100], // Color similar al de la foto
                  backgroundColor: Colors.blue[50], // Color similar al de la foto
                );
              }).toList(),
            ),
            const SizedBox(height: 16.0),
            if (searchResults.isEmpty && searchTerm.isEmpty && selectedTags.isEmpty)
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.help_outline, size: 100, color: Colors.grey),
                      const SizedBox(height: 16.0),
                      const Text(
                        '¿De qué necesitas asesorarte hoy?',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              )
            else if (searchResults.isEmpty)
              Expanded(
                child: Center(
                  child: const Text(
                    'No se encontraron resultados',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ),
              )
            else
              Expanded(
                child: ListView.builder(
                  itemCount: searchResults.length,
                  itemBuilder: (context, index) {
                    var advisory = searchResults[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8.0),
                      child: ListTile(
                        contentPadding: EdgeInsets.all(10),
                        leading: advisory['imagenURL'] != null
                            ? Image.network(advisory['imagenURL'], width: 50, height: 50, fit: BoxFit.cover)
                            : const Icon(Icons.image, size: 50),
                        title: Text(advisory['nombreMateria'] ?? 'Sin nombre'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(advisory['descripcion'] ?? 'Sin descripción'),
                            Text('Fecha: ${advisory['fecha'].toString().split(' ')[0]}'),
                            Text('Modalidad: ${advisory['modalidad']}'),
                          ],
                        ),
                        onTap: () {
                          // Navegar a la página de detalles de la asesoría
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => AdvisoryDetailScreen(advisory: advisory),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class AdvisoryDetailScreen extends StatelessWidget {
  final Map<String, dynamic> advisory;

  const AdvisoryDetailScreen({required this.advisory});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(advisory['nombreMateria'] ?? 'Detalles de Asesoría'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (advisory['imagenURL'] != null)
              Image.network(advisory['imagenURL'], width: double.infinity, height: 200, fit: BoxFit.cover),
            const SizedBox(height: 16.0),
            Text(advisory['nombreMateria'] ?? 'Sin nombre', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8.0),
            Text(advisory['descripcion'] ?? 'Sin descripción'),
            const SizedBox(height: 8.0),
            Text('Fecha: ${advisory['fecha'].toString().split(' ')[0]}'),
            const SizedBox(height: 8.0),
            Text('Hora: ${advisory['hora']}'),
            const SizedBox(height: 8.0),
            Text('Modalidad: ${advisory['modalidad']}'),
            if (advisory['modalidad'] == 'Presencial') Text('Lugar: ${advisory['lugar']}'),
            const SizedBox(height: 8.0),
            Wrap(
              spacing: 8.0,
              runSpacing: 4.0,
              children: (advisory['tags'] as List<dynamic>).map((tag) {
                return Chip(label: Text(tag.toString()));
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}